import { Module } from '@nestjs/common';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { User, userSchema } from './schema/user.schema';
import { HealthPreference, healthPreferenceSchema } from './schema/health_preference.schema';
import { ProfessionalDetails, professionalDetailsSchema } from './schema/professional_details.schema';

@Module({
  imports: [MongooseModule.forFeature([{name: User.name, schema: userSchema}, {name: HealthPreference.name, schema: healthPreferenceSchema}, {name: ProfessionalDetails.name, schema: professionalDetailsSchema}])],
  controllers: [UsersController],
  providers: [UsersService],
})
export class UsersModule {}

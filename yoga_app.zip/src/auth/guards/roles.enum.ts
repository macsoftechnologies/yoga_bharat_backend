export enum Role {
    ADMIN = 'admin',
    CLIENT = 'client',
    TRAINER = 'trainer'
}
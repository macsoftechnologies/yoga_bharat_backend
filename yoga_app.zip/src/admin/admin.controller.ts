import {
  Body,
  Controller,
  HttpStatus,
  Param,
  Post,
  Put,
  UseGuards,
} from '@nestjs/common';
import { AdminService } from './admin.service';
import { adminDto } from './dto/admin.dto';
import { ApiBody, ApiOkResponse } from '@nestjs/swagger';
import { JwtGuard } from 'src/auth/guards/jwt.guard';
import { RolesGuard } from 'src/auth/guards/roles.guard';
import { Role } from 'src/auth/guards/roles.enum';
import { Roles } from 'src/auth/guards/roles.decorator';

@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Post('/adminregister')
  async adminRegister(@Body() req: adminDto) {
    try {
      const registerAdmin = await this.adminService.createAdmin(req);
      return registerAdmin;
    } catch (error) {
      return {
        statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
        message: error,
      };
    }
  }

  @Post('/loginadmin')
  async loginRegister(@Body() req: adminDto) {
    try {
      const loginadmin = await this.adminService.loginAdmin(req);
      return loginadmin;
    } catch (error) {
      return {
        statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
        message: error,
      };
    }
  }

  @Post('/adminforgotpassword')
  async adminForgotPassword(@Body() req: adminDto) {
    try {
      const adminpassword = await this.adminService.forgotPassword(req);
      return adminpassword;
    } catch (error) {
      return {
        statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
        message: error,
      };
    }
  }
}
